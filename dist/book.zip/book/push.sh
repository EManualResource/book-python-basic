#!/bin/bash

echo 'Push to origin master'
git push origin master
echo 'Push to osc master'
git push osc master
