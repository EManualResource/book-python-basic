#! /usr/bin/env python
#coding:utf-8

"""
请计算：19+2*4-8/2
"""

a = 19+2*4-8/2
print a
