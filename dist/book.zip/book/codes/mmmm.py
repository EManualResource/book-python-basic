#!/usr/bin/env python
#coding:utf-8

web = "https://qiwsir.github.io, I am writing a python book on line."

def my_name(name):
    print name

class pythoner:
    def __init__(self,lang):
        self.lang = lang
    def programmer(self):
        print "python programmer language is: ",self.lang
