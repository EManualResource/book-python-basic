#coding:utf-8

def add_function(a,b):
    c = a+b
    print c

if __name__=="__main__":
    add_function(2,3)
