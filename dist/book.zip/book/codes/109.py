#coding:utf-8

print "please write your name:"

name=raw_input()

print "Hello,%s"%name


